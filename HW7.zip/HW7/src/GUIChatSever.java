import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;



public class GUIChatSever extends JFrame{
	
	static JTextArea MSGView = new JTextArea();
	
	
	
	GUIChatSever(){
		setTitle("Server");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		
		
		MSGView.setLineWrap(true); //한줄이 너무 길면 자동으로 개행할지 설정
		MSGView.setEditable(false); //수정불
		JScrollPane jsp = new JScrollPane(MSGView);

		add(jsp,"Center");
		
		JTextField Input_msg = new JTextField();
		add(Input_msg,"South");
		Input_msg.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Input_msg.setText("");
				MSGView.append(e.getActionCommand()+"\n");
				jsp.getVerticalScrollBar().setValue(jsp.getVerticalScrollBar().getMaximum());
			}
		});
		
		setSize(300,320);
		setVisible(true);
	}
		
	
	public static void main(String[] args) {
		GUIChatSever chatserver = new GUIChatSever();
		
		try{		
			ServerSocket server = new ServerSocket(10001);	
			MSGView.append("접속을 기다립니다. \n");	
			HashMap hm = new HashMap();	
			while(true){	
				Socket sock = server.accept();
				ChatThread chatthread = new ChatThread(sock, hm, MSGView);
				chatthread.start();
			} // while	
		}catch(Exception e){	
			System.out.println(e);
		}
		
	}
	
		
}
